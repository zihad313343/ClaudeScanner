package com.eduscan.netscan.network

/**
 * Static dictionary of common subdomain labels for passive, dictionary-based
 * enumeration (the same technique tools like Sublist3r/gobuster use for their
 * default wordlists - these are all standard, widely-known naming conventions,
 * not anything sensitive).
 *
 * This performs plain DNS resolution only - it never touches the target's
 * HTTP/TCP services, so it's a good first, low-noise step before pointing the
 * Port & Service Scanner at anything it finds.
 */
object SubdomainWordlist {

    /** Fast pass: the handful of labels that account for most real subdomains. */
    val quick: List<String> = listOf(
        "www", "mail", "ftp", "webmail", "smtp", "pop", "imap", "ns1", "ns2",
        "api", "app", "dev", "staging", "test", "admin", "portal", "vpn",
        "cdn", "static", "blog", "shop", "m", "mobile", "secure", "login",
        "dashboard", "support", "docs", "status", "git", "cloud"
    )

    /** Broader pass: quick + a wider set of infrastructure/environment labels. */
    val standard: List<String> = quick + listOf(
        "autodiscover", "autoconfig", "owa", "exchange", "mx", "mta", "relay",
        "dns", "ns3", "ns4", "sftp", "ssh", "remote", "beta", "demo", "sandbox",
        "old", "new", "legacy", "backup", "db", "database", "sql", "mysql",
        "redis", "cache", "proxy", "gateway", "lb", "edge", "assets", "media",
        "files", "images", "img", "download", "downloads", "upload", "uploads",
        "s3", "storage", "monitor", "grafana", "kibana", "jenkins", "ci",
        "gitlab", "jira", "confluence", "wiki", "forum", "store", "sso",
        "auth", "id", "my", "panel", "cpanel", "whm", "direct", "ssl", "uat",
        "qa", "preprod", "prod", "production", "release", "build", "intranet",
        "extranet", "internal", "corp", "partners", "developer", "developers",
        "api2", "apidocs", "v1", "v2", "help", "wap", "ipv6", "webdisk",
        "ns", "mail2", "smtp2", "ftp2", "server", "host", "web", "web2"
    )
}
