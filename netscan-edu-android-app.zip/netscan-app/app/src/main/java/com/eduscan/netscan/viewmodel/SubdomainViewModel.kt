package com.eduscan.netscan.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.eduscan.netscan.model.SubdomainScanUiState
import com.eduscan.netscan.model.SubdomainWordlistSize
import com.eduscan.netscan.network.SubdomainFinder
import com.eduscan.netscan.network.SubdomainWordlist
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class SubdomainViewModel : ViewModel() {

    var uiState by mutableStateOf(SubdomainScanUiState())
        private set

    private var scanJob: Job? = null

    // Same reasoning as PortScanViewModel: onChecked/onFound fire concurrently from up to
    // MAX_CONCURRENCY background threads, so state mutations must be serialized to avoid
    // lost updates (a stalled progress count, or a found subdomain dropped from the list).
    private val stateLock = Any()

    fun startScan(domainInput: String, wordlistSize: SubdomainWordlistSize) {
        if (domainInput.isBlank()) return
        scanJob?.cancel()

        val labels = when (wordlistSize) {
            SubdomainWordlistSize.QUICK -> SubdomainWordlist.quick
            SubdomainWordlistSize.STANDARD -> SubdomainWordlist.standard
        }

        uiState = SubdomainScanUiState(
            isScanning = true,
            domainInput = domainInput,
            subdomainsTotal = labels.size
        )

        scanJob = viewModelScope.launch {
            try {
                val rootDomain = SubdomainFinder.normalizeDomain(domainInput)

                SubdomainFinder.scan(
                    rootDomain = rootDomain,
                    labels = labels,
                    onChecked = {
                        synchronized(stateLock) {
                            uiState = uiState.copy(subdomainsScanned = uiState.subdomainsScanned + 1)
                        }
                    },
                    onFound = { result ->
                        synchronized(stateLock) {
                            uiState = uiState.copy(
                                found = (uiState.found + result).sortedBy { it.subdomain }
                            )
                        }
                    }
                )
                uiState = uiState.copy(isScanning = false, finished = true)
            } catch (e: SubdomainFinder.InvalidDomainException) {
                uiState = uiState.copy(
                    isScanning = false,
                    error = e.message ?: "Enter a valid domain",
                    finished = true
                )
            } catch (e: Exception) {
                uiState = uiState.copy(
                    isScanning = false,
                    error = "Scan failed: ${e.message}",
                    finished = true
                )
            }
        }
    }

    fun cancelScan() {
        scanJob?.cancel()
        uiState = uiState.copy(isScanning = false)
    }

    fun reset() {
        scanJob?.cancel()
        uiState = SubdomainScanUiState()
    }
}
