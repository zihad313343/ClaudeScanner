package com.eduscan.netscan.viewmodel

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.eduscan.netscan.model.LocalScanUiState
import com.eduscan.netscan.network.LocalNetworkScanner
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class LocalNetworkViewModel : ViewModel() {

    var uiState by mutableStateOf(LocalScanUiState())
        private set

    private var scanJob: Job? = null

    // See PortScanViewModel for why this lock is needed: onHostChecked/onDeviceFound fire
    // concurrently from many background threads, and unguarded "uiState = uiState.copy(...)"
    // read-modify-writes can lose updates (a stalled progress count, or a found device
    // silently dropped from the list).
    private val stateLock = Any()

    fun startScan(context: Context) {
        scanJob?.cancel()

        val subnet = LocalNetworkScanner.getSubnetInfo(context)
        if (subnet == null) {
            uiState = LocalScanUiState(
                error = "Couldn't read WiFi info. Make sure you're connected to a WiFi network.",
                finished = true
            )
            return
        }

        uiState = LocalScanUiState(
            isScanning = true,
            subnetCidr = subnet.cidr,
            localIp = subnet.localIp,
            hostsTotal = subnet.hosts.size
        )

        scanJob = viewModelScope.launch {
            try {
                LocalNetworkScanner.scanSubnet(
                    hosts = subnet.hosts,
                    localIp = subnet.localIp,
                    onHostChecked = {
                        synchronized(stateLock) {
                            uiState = uiState.copy(hostsScanned = uiState.hostsScanned + 1)
                        }
                    },
                    onDeviceFound = { device ->
                        synchronized(stateLock) {
                            uiState = uiState.copy(
                                devices = (uiState.devices + device).sortedBy {
                                    it.ip.split(".").last().toIntOrNull() ?: 0
                                }
                            )
                        }
                    }
                )
                uiState = uiState.copy(isScanning = false, finished = true)
            } catch (e: Exception) {
                uiState = uiState.copy(
                    isScanning = false,
                    error = "Scan failed: ${e.message}",
                    finished = true
                )
            }
        }
    }

    fun cancelScan() {
        scanJob?.cancel()
        uiState = uiState.copy(isScanning = false)
    }

    fun reset() {
        scanJob?.cancel()
        uiState = LocalScanUiState()
    }
}
