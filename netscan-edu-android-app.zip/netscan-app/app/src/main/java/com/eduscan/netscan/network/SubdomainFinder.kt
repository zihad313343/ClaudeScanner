package com.eduscan.netscan.network

import com.eduscan.netscan.model.SubdomainResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.UnknownHostException

/**
 * Dictionary-based subdomain enumeration: tries "label.domain" for every label
 * in a wordlist and reports the ones that resolve to a live IP address.
 *
 * NOTE ON TIMEOUTS: java.net.InetAddress has no timeout parameter at all for
 * name resolution - unlike Socket.connect(), there's no API to bound it, and
 * no open socket to force-close as a backstop (see PortScanner for that
 * technique). So instead we run each lookup on its own short-lived daemon
 * thread and bound our *wait* with Thread.join(timeoutMs), the same pattern
 * LocalNetworkScanner already uses for reverse-DNS. A lookup against a slow
 * or non-responsive resolver can't stall the overall scan past the timeout,
 * even though the abandoned thread may keep resolving in the background
 * briefly before it's garbage collected.
 */
object SubdomainFinder {

    private const val LOOKUP_TIMEOUT_MS = 2000L
    private const val MAX_CONCURRENCY = 48

    class InvalidDomainException(message: String) : Exception(message)

    /** Strips a scheme/path/trailing dot so "https://example.com/" and "example.com" behave the same. */
    fun normalizeDomain(input: String): String {
        var domain = input.trim().lowercase()
        domain = domain.removePrefix("https://").removePrefix("http://")
        domain = domain.substringBefore("/")
        domain = domain.removeSuffix(".")
        if (domain.isBlank() || !domain.contains(".")) {
            throw InvalidDomainException("Enter a valid domain, e.g. example.com")
        }
        return domain
    }

    suspend fun scan(
        rootDomain: String,
        labels: List<String>,
        onChecked: () -> Unit,
        onFound: (SubdomainResult) -> Unit
    ) = coroutineScope {
        val semaphore = Semaphore(MAX_CONCURRENCY)
        labels.map { label ->
            async(Dispatchers.IO) {
                semaphore.withPermit {
                    val result = probeSubdomain(label, rootDomain)
                    onChecked()
                    if (result != null) onFound(result)
                }
            }
        }.awaitAll()
    }

    private suspend fun probeSubdomain(label: String, rootDomain: String): SubdomainResult? {
        val fqdn = "$label.$rootDomain"
        val start = System.currentTimeMillis()
        val ip = resolveWithTimeout(fqdn) ?: return null
        val elapsed = System.currentTimeMillis() - start
        return SubdomainResult(subdomain = fqdn, ip = ip, responseTimeMs = elapsed)
    }

    private suspend fun resolveWithTimeout(fqdn: String, timeoutMs: Long = LOOKUP_TIMEOUT_MS): String? =
        withContext(Dispatchers.IO) {
            var result: String? = null
            val thread = Thread {
                try {
                    result = InetAddress.getByName(fqdn).hostAddress
                } catch (e: UnknownHostException) {
                    // NXDOMAIN / no record - this subdomain simply doesn't exist, not an error.
                } catch (e: Exception) {
                    // any other resolver hiccup - treat the same as "not found"
                }
            }
            thread.isDaemon = true
            thread.start()
            thread.join(timeoutMs)
            result
        }
}
