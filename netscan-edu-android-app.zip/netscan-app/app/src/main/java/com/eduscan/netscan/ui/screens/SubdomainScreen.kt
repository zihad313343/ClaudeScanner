package com.eduscan.netscan.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.eduscan.netscan.model.SubdomainResult
import com.eduscan.netscan.model.SubdomainWordlistSize
import com.eduscan.netscan.ui.components.*
import com.eduscan.netscan.ui.theme.*
import com.eduscan.netscan.viewmodel.SubdomainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubdomainScreen(onBack: () -> Unit, viewModel: SubdomainViewModel = viewModel()) {
    val state = viewModel.uiState
    var domain by remember { mutableStateOf("") }
    var wordlistSize by remember { mutableStateOf(SubdomainWordlistSize.QUICK) }

    Scaffold(
        containerColor = BgDeep,
        topBar = {
            TopAppBar(
                title = { Text("Subdomain Finder") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgSurfaceElevated, titleContentColor = TextPrimary, navigationIconContentColor = TextPrimary)
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {

            SectionCard {
                OutlinedTextField(
                    value = domain,
                    onValueChange = { domain = it },
                    label = { Text("Domain") },
                    placeholder = { Text("e.g. example.com") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !state.isScanning,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MagentaAccent,
                        cursorColor = MagentaAccent
                    )
                )

                Spacer(Modifier.height(14.dp))
                Text("Wordlist", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = wordlistSize == SubdomainWordlistSize.QUICK,
                        onClick = { wordlistSize = SubdomainWordlistSize.QUICK },
                        label = { Text("Quick (~30)") },
                        enabled = !state.isScanning
                    )
                    FilterChip(
                        selected = wordlistSize == SubdomainWordlistSize.STANDARD,
                        onClick = { wordlistSize = SubdomainWordlistSize.STANDARD },
                        label = { Text("Standard (~120)") },
                        enabled = !state.isScanning
                    )
                }

                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = { viewModel.startScan(domain, wordlistSize) },
                    enabled = !state.isScanning && domain.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MagentaAccent, contentColor = BgDeep)
                ) {
                    if (state.isScanning) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = BgDeep, strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Searching…")
                    } else {
                        Icon(Icons.Filled.Dns, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Find Subdomains")
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            if (state.error != null) {
                SectionCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = StatusError)
                        Spacer(Modifier.width(8.dp))
                        Text(state.error, color = StatusError, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            if (state.subdomainsTotal > 0) {
                ScanProgressBar(state.subdomainsScanned, state.subdomainsTotal)
                Spacer(Modifier.height(14.dp))
            }

            if (state.found.isEmpty() && state.finished && state.error == null) {
                EmptyState(
                    icon = { Icon(Icons.Filled.Dns, contentDescription = null, tint = TextMuted, modifier = Modifier.size(40.dp)) },
                    title = "No subdomains found",
                    subtitle = "None of the tried labels resolved. Try the Standard wordlist for wider coverage."
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(state.found) { result ->
                        SubdomainResultCard(result)
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }
        }
    }
}

@Composable
private fun SubdomainResultCard(result: SubdomainResult) {
    SectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusDot(StatusOpen)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    result.subdomain,
                    color = TextPrimary,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
                PortStatusChip(result.ip, MagentaAccent)
            }
            Text("${result.responseTimeMs}ms", color = TextMuted, style = MaterialTheme.typography.labelSmall)
        }
    }
}
