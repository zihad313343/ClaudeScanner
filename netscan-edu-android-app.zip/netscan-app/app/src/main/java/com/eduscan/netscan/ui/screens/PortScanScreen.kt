package com.eduscan.netscan.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.eduscan.netscan.model.PortRangeMode
import com.eduscan.netscan.model.PortResult
import com.eduscan.netscan.ui.components.*
import com.eduscan.netscan.ui.theme.*
import com.eduscan.netscan.viewmodel.PortScanViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PortScanScreen(onBack: () -> Unit, viewModel: PortScanViewModel = viewModel()) {
    val state = viewModel.uiState
    var host by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(PortRangeMode.COMMON) }
    var customStart by remember { mutableStateOf("1") }
    var customEnd by remember { mutableStateOf("1024") }

    Scaffold(
        containerColor = BgDeep,
        topBar = {
            TopAppBar(
                title = { Text("Port & Service Scanner") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgSurfaceElevated, titleContentColor = TextPrimary, navigationIconContentColor = TextPrimary)
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {

            SectionCard {
                OutlinedTextField(
                    value = host,
                    onValueChange = { host = it },
                    label = { Text("IP address or domain") },
                    placeholder = { Text("e.g. 192.168.1.10 or example.com") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !state.isScanning,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanAccent,
                        cursorColor = CyanAccent
                    )
                )

                Spacer(Modifier.height(14.dp))
                Text("Port range", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = mode == PortRangeMode.COMMON,
                        onClick = { mode = PortRangeMode.COMMON },
                        label = { Text("Common (~65)") },
                        enabled = !state.isScanning
                    )
                    FilterChip(
                        selected = mode == PortRangeMode.WELL_KNOWN,
                        onClick = { mode = PortRangeMode.WELL_KNOWN },
                        label = { Text("1–1023") },
                        enabled = !state.isScanning
                    )
                    FilterChip(
                        selected = mode == PortRangeMode.CUSTOM,
                        onClick = { mode = PortRangeMode.CUSTOM },
                        label = { Text("Custom") },
                        enabled = !state.isScanning
                    )
                }

                if (mode == PortRangeMode.CUSTOM) {
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = customStart, onValueChange = { customStart = it.filter { c -> c.isDigit() } },
                            label = { Text("Start") }, modifier = Modifier.weight(1f), enabled = !state.isScanning,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CyanAccent, cursorColor = CyanAccent)
                        )
                        OutlinedTextField(
                            value = customEnd, onValueChange = { customEnd = it.filter { c -> c.isDigit() } },
                            label = { Text("End") }, modifier = Modifier.weight(1f), enabled = !state.isScanning,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CyanAccent, cursorColor = CyanAccent)
                        )
                    }
                }

                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = {
                        viewModel.startScan(
                            host, mode,
                            customStart.toIntOrNull() ?: 1,
                            customEnd.toIntOrNull() ?: 1024
                        )
                    },
                    enabled = !state.isScanning && host.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = BgDeep)
                ) {
                    if (state.isScanning) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = BgDeep, strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Scanning…")
                    } else {
                        Icon(Icons.Filled.Radar, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Start Scan")
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            if (state.resolvedIp != null) {
                Text(
                    "Target: ${state.hostInput}  →  ${state.resolvedIp}",
                    color = TextSecondary,
                    style = MaterialTheme.typography.labelSmall
                )
                Spacer(Modifier.height(10.dp))
            }

            if (state.resolutionError != null) {
                SectionCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = StatusError)
                        Spacer(Modifier.width(8.dp))
                        Text(state.resolutionError, color = StatusError, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            if (state.portsTotal > 0) {
                ScanProgressBar(state.portsScanned, state.portsTotal)
                Spacer(Modifier.height(14.dp))
            }

            if (state.openPorts.isEmpty() && state.finished && state.resolutionError == null) {
                EmptyState(
                    icon = { Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = StatusOpen, modifier = Modifier.size(40.dp)) },
                    title = "No open ports found",
                    subtitle = "None of the scanned ports responded. Try a wider range."
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(state.openPorts) { result ->
                        PortResultCard(result)
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }
        }
    }
}

@Composable
private fun PortResultCard(result: PortResult) {
    SectionCard {
        Row(verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusDot(StatusOpen)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Port ${result.port}",
                        color = TextPrimary,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.width(10.dp))
                    PortStatusChip(result.serviceName, CyanAccent)
                }
                if (result.versionGuess != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        result.versionGuess,
                        color = StatusWarning,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                if (result.banner != null) {
                    Spacer(Modifier.height(6.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .background(BgSurface, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            result.banner.take(200),
                            color = TextSecondary,
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 3
                        )
                    }
                }
            }
            Text("${result.responseTimeMs}ms", color = TextMuted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun viewModel(): PortScanViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
