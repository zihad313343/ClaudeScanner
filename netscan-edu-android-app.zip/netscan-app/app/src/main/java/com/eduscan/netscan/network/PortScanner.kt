package com.eduscan.netscan.network

import com.eduscan.netscan.model.PortResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import java.net.UnknownHostException

object PortScanner {

    private const val CONNECT_TIMEOUT_MS = 600
    // Hard backstop, always a bit larger than CONNECT_TIMEOUT_MS + banner-grab time. Guarantees
    // that no single port - regardless of flaky mobile-network/OS socket-timeout behavior - can
    // ever stall the overall scan past this ceiling.
    private const val HARD_TIMEOUT_MS = 3000L
    private const val MAX_CONCURRENCY = 128

    class ResolutionException(message: String) : Exception(message)

    /** Resolves a hostname/domain or validates an IP literal. Throws ResolutionException on failure. */
    suspend fun resolveHost(hostInput: String): String = withContext(Dispatchers.IO) {
        try {
            java.net.InetAddress.getByName(hostInput.trim()).hostAddress
                ?: throw ResolutionException("Could not resolve $hostInput")
        } catch (e: UnknownHostException) {
            throw ResolutionException("Could not resolve host: $hostInput")
        }
    }

    /**
     * Scans [ports] against [resolvedIp] concurrently. Calls [onPortChecked] after every
     * single port attempt (open or closed) for progress reporting, and [onOpenPort]
     * immediately when an open port with a banner is found.
     */
    suspend fun scan(
        resolvedIp: String,
        ports: List<Int>,
        onPortChecked: () -> Unit,
        onOpenPort: (PortResult) -> Unit
    ) = coroutineScope {
        val semaphore = Semaphore(MAX_CONCURRENCY)
        ports.map { port ->
            async(Dispatchers.IO) {
                semaphore.withPermit {
                    val result = probePortWithHardTimeout(resolvedIp, port)
                    onPortChecked()
                    if (result != null) onOpenPort(result)
                }
            }
        }.awaitAll()
    }

    /**
     * NOTE: probePort() below is a plain blocking function (Socket.connect / stream reads),
     * not a suspend function - it has no suspension points. That means withTimeoutOrNull()
     * CANNOT cancel it: coroutine cancellation is cooperative and only takes effect at a
     * suspension checkpoint, of which a blocking call has none. If Socket.connect() ever
     * ignores its own timeout (seen in practice on some Android/carrier combos - e.g. a
     * firewall silently dropping packets instead of sending RST), the coroutine-level
     * timeout alone would never fire and that one port would hang the whole scan forever.
     *
     * The actual fix: race probePort() against a watchdog coroutine that force-closes the
     * socket after HARD_TIMEOUT_MS. Closing a socket from another thread genuinely interrupts
     * a blocking connect()/read() in progress (throws SocketException), which unblocks the
     * IO thread and lets probePort's own catch block return null as "closed/timed out".
     */
    private suspend fun probePortWithHardTimeout(ip: String, port: Int): PortResult? = coroutineScope {
        val socket = Socket()
        val watchdog = launch {
            delay(HARD_TIMEOUT_MS)
            try { socket.close() } catch (_: Exception) {}
        }
        try {
            withContext(Dispatchers.IO) { probePort(socket, ip, port) }
        } finally {
            watchdog.cancel()
            try { socket.close() } catch (_: Exception) {}
        }
    }

    private fun probePort(socket: Socket, ip: String, port: Int): PortResult? {
        return try {
            val start = System.currentTimeMillis()
            socket.connect(InetSocketAddress(ip, port), CONNECT_TIMEOUT_MS)
            val elapsed = System.currentTimeMillis() - start

            val banner = BannerGrabber.grab(socket, ip, port)
            PortResult(
                port = port,
                serviceName = ServiceDatabase.nameFor(port),
                banner = banner.rawBanner,
                versionGuess = banner.versionGuess,
                responseTimeMs = elapsed
            )
        } catch (e: Exception) {
            null // closed, filtered, force-closed by watchdog, or timed out - not reported as open
        }
    }
}
