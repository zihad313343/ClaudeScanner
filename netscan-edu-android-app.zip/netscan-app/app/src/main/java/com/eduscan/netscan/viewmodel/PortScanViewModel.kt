package com.eduscan.netscan.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.eduscan.netscan.model.PortRangeMode
import com.eduscan.netscan.model.PortScanUiState
import com.eduscan.netscan.network.PortScanner
import com.eduscan.netscan.network.ServiceDatabase
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class PortScanViewModel : ViewModel() {

    var uiState by mutableStateOf(PortScanUiState())
        private set

    private var scanJob: Job? = null

    // onPortChecked/onOpenPort below fire concurrently from up to MAX_CONCURRENCY background
    // threads at once. "uiState = uiState.copy(x = uiState.x + 1)" is a read-modify-write that
    // is NOT atomic - two threads can both read the same uiState before either writes back,
    // silently dropping one update (a lost progress increment, or worse, a discovered open port
    // vanishing from the results list). This lock serializes those mutations.
    private val stateLock = Any()

    fun startScan(host: String, mode: PortRangeMode, customStart: Int, customEnd: Int) {
        if (host.isBlank()) return
        scanJob?.cancel()

        val ports = when (mode) {
            PortRangeMode.COMMON -> ServiceDatabase.commonPorts
            PortRangeMode.WELL_KNOWN -> ServiceDatabase.wellKnownRange.toList()
            PortRangeMode.CUSTOM -> {
                val lo = customStart.coerceIn(1, 65535)
                val hi = customEnd.coerceIn(lo, 65535)
                (lo..hi).toList()
            }
        }

        uiState = PortScanUiState(
            isScanning = true,
            hostInput = host,
            portsTotal = ports.size
        )

        scanJob = viewModelScope.launch {
            try {
                val ip = PortScanner.resolveHost(host)
                uiState = uiState.copy(resolvedIp = ip)

                PortScanner.scan(
                    resolvedIp = ip,
                    ports = ports,
                    onPortChecked = {
                        synchronized(stateLock) {
                            uiState = uiState.copy(portsScanned = uiState.portsScanned + 1)
                        }
                    },
                    onOpenPort = { result ->
                        synchronized(stateLock) {
                            uiState = uiState.copy(
                                openPorts = (uiState.openPorts + result).sortedBy { it.port }
                            )
                        }
                    }
                )
                uiState = uiState.copy(isScanning = false, finished = true)
            } catch (e: PortScanner.ResolutionException) {
                uiState = uiState.copy(
                    isScanning = false,
                    resolutionError = e.message ?: "Could not resolve host",
                    finished = true
                )
            } catch (e: Exception) {
                uiState = uiState.copy(
                    isScanning = false,
                    resolutionError = "Scan failed: ${e.message}",
                    finished = true
                )
            }
        }
    }

    fun cancelScan() {
        scanJob?.cancel()
        uiState = uiState.copy(isScanning = false)
    }

    fun reset() {
        scanJob?.cancel()
        uiState = PortScanUiState()
    }
}
