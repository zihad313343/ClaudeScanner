package com.eduscan.netscan.ui.theme

import androidx.compose.ui.graphics.Color

// ---------------------------------------------------------------------------
// "Dual-Trace Oscilloscope" palette.
// Grounded in the subject: a warm-black instrument chassis, an etched grid,
// and two signal colors borrowed straight from a scope's CH1/CH2 traces -
// amber for the Port & Service Scanner, teal for the Local Network Scanner.
// Deliberately not navy-and-cyan: this is a warmer, more "hardware panel"
// register than the generic dark-dashboard look.
// ---------------------------------------------------------------------------

// Chassis / panels
val BgDeep = Color(0xFF0A0A08)             // instrument body
val BgSurface = Color(0xFF141310)          // panel
val BgSurfaceElevated = Color(0xFF1D1B15)  // raised panel / header
val BgCard = Color(0xFF17160F)             // card fill

// Signal colors (channel 1 = amber / channel 2 = teal / channel 3 = magenta -
// the same CH1-4 color convention real oscilloscopes use)
val CyanAccent = Color(0xFFFFB300)         // CH.1 - amber phosphor (Port Scanner)
val CyanAccentDim = Color(0xFFB37D00)      // CH.1 dimmed trace
val PurpleAccent = Color(0xFF4FD8C4)       // CH.2 - teal trace (Local Network)
val IndigoAccent = Color(0xFF2F9E8F)       // CH.2 dimmed trace
val MagentaAccent = Color(0xFFE8609E)      // CH.3 - magenta trace (Subdomain Finder)
val MagentaAccentDim = Color(0xFFA83D71)   // CH.3 dimmed trace

// Status colors
val StatusOpen = Color(0xFF6EE7A0)     // open port / reachable device
val StatusClosed = Color(0xFF5C5747)   // closed / filtered
val StatusWarning = Color(0xFFFF8F3D)  // caution lamp
val StatusError = Color(0xFFFF5C5C)    // error / unreachable

// Text
val TextPrimary = Color(0xFFEDEAE0)
val TextSecondary = Color(0xFFA39D8A)
val TextMuted = Color(0xFF6E6957)

// Etched grid line / hairline border
val BorderSubtle = Color(0xFF2E2A1C)
